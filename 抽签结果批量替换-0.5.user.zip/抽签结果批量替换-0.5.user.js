// ==UserScript==
// @name         抽签结果批量替换
// @namespace    http://tampermonkey.net/
// @version      0.5
// @description  自定义将抽签网站上显示的特定数字替换为其他数字，支持多个批量替换规则
// @author       hjlhhh
// @match        http://120.53.106.11/*
// @grant        none
// @run-at       document-idle
// ==/UserScript==

(function() {
    'use strict';

    // 定义一个映射表，用于指定哪些数字需要被替换，以及它们应该被替换成什么数字
    const numberMap = {
        '37': '45', // 将37替换为45
        '49': '50', // 将10替换为20
        // 你可以继续在这里添加更多的替换规则
    };

    // 定义多个批量替换规则
    const batchReplaceRules = [
        {
            start: 0, // 起始数字
            end: 0, // 结束数字
            target: '0' // 无
        },
        {
            start: 0, // 起始数字
            end: 0, // 结束数字
            target: '0' //无
        }
        // 你可以继续在这里添加更多的批量替换规则
    ];

    // 定义一个函数来检查并修改页面上的数字
    function modifyNumbers() {
        // 获取页面上所有可能包含数字的元素
        const elements = document.querySelectorAll('body *');

        elements.forEach(function(element) {
            // 检查元素的文本内容是否为数字
            const textContent = element.textContent.trim();
            if (!isNaN(textContent) && textContent !== '') {
                // 检查是否在映射表中
                if (numberMap[textContent]) {
                    element.textContent = numberMap[textContent];
                }
                // 检查是否在批量替换规则中
                else {
                    for (const rule of batchReplaceRules) {
                        if (textContent >= rule.start && textContent <= rule.end) {
                            element.textContent = rule.target;
                            break; // 应用规则后退出循环
                        }
                    }
                }
            }
        });
    }

    // 定期检查并修改页面上的数字，这里设置为每秒检查一次
    setInterval(modifyNumbers, 1000);
})();